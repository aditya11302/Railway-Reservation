document
  .querySelector("#search-form")
  .addEventListener("submit", function (event) {
    event.preventDefault();
    const resultsSection = document.getElementById("results-section");
    resultsSection.innerHTML = ""; // Clear previous results

    const sampleData = [
      {
        trainName: "11302 Udyan Express",
        from: "KSR Bengaluru City",
        to: "Mumbai CSMT",
        departure: "8:30 PM",
        arrival: "8:00 PM",
        availability: "Available",
      },
      {
        trainName: "12859 Gitanjali Express",
        from: "Mumbai CSMT",
        to: "Howrah",
        departure: "6:00 AM",
        arrival: "2:00 PM",
        availability: "Waiting List",
      },
      {
        trainName: "22895 Vande Bharat Express",
        from: "Howrah",
        to: "Puri",
        departure: "12:00 PM",
        arrival: "4:00 PM",
        availability: "Available",
      },
      {
        trainName: "12278 Shatabdi Express",
        from: "Puri",
        to: "Howrah",
        departure: "5:30 AM",
        arrival: "1:30 PM",
        availability: "Available",
      },
      {
        trainName: "12841 Coromondal Express",
        from: "Shalimar",
        to: "Chennai Central",
        departure: "3:00 PM",
        arrival: "5:00 PM",
        availability: "Waiting List",
      },
      {
        trainName: "11013 LTT Coimbatore Express",
        from: "Mumbai LTT",
        to: "Coimbatore",
        departure: "9:30 PM",
        arrival: "9:00 PM",
        availability: "Available",
      },
      {
        trainName: "12429 Lucknow New Delhi AC Express",
        from: "Lucknow",
        to: "New Delhi",
        departure: "11:30 PM",
        arrival: "7:30 AM",
        availability: "Waiting List",
      },
      {
        trainName: "22222 Rajdhani Express",
        from: "Hazrat Nizamuddin",
        to: "Mumbai CSMT",
        departure: "5:00 PM",
        arrival: "10:30 AM",
        availability: "Available",
      },
      {
        trainName: "12222 Duranto Express",
        from: "Howrah",
        to: "Pune",
        departure: "5:30 PM",
        arrival: "10:30 AM",
        availability: "Available",
      },
      {
        trainName: "12045 Shatabdi Express",
        from: "New Delhi",
        to: "Chandigarh",
        departure: "7:00 PM",
        arrival: "10:30 PM",
        availability: "Available",
      },
      {
        trainName: "12311 Netaji Express",
        from: "Howrah",
        to: "Kalka",
        departure: "10:00 PM",
        arrival: "3:00 AM",
        availability: "Waiting List",
      },
      {
        trainName: "12955 Mumbai Central Jaipur Express",
        from: "Mumbai Central",
        to: "Jaipur",
        departure: "7:00 PM",
        arrival: "12:00 PM",
        availability: "Available",
      },
      {
        trainName: "16722 Intercity Express",
        from: "Madurai",
        to: "Coimbatore",
        departure: "7:00 AM",
        arrival: "12:00 PM",
        availability: "Available",
      },
      {
        trainName: "17230 Sabari Express",
        from: "Secunderabad",
        to: "Trivandrum",
        departure: "12:30 PM",
        arrival: "6:00 PM",
        availability: "Available",
      },
      {
        trainName: "14542 Amritsar Chandigarh Express",
        from: "Amritsar",
        to: "Chandigarh",
        departure: "6:00 AM",
        arrival: "10:00 AM",
        availability: "Waiting List",
      },
      {
        trainName: "12982 Ahmedabad Jaipur Express",
        from: "Ahmedabad",
        to: "Jaipur",
        departure: "8:00 PM",
        arrival: "7:30 AM",
        availability: "Available",
      },
      {
        trainName: "22356 Chandigarh Patliputra Express",
        from: "Chandigarh",
        to: "Patliputa",
        departure: "9:30 PM",
        arrival: "2:30 PM",
        availability: "Available",
      },
      {
        trainName: "22688 Varanasi Mysuru Express",
        from: "Varanasi",
        to: "Mysuru",
        departure: "9:00 PM",
        arrival: "10:00 PM",
        availability: "Waiting List",
      },
      {
        trainName: "22717 Rajkot Secunderabad Express",
        from: "Rajkot",
        to: "Secunderabad",
        departure: "5:30 AM",
        arrival: "8:00 AM",
        availability: "Available",
      },
      {
        trainName: "20897 Vande Bharat Express",
        from: "Howrah",
        to: "Ranchi",
        departure: "2:30 PM",
        arrival: "10:00 PM",
        availability: "Available",
      },
      {
        trainName: "11058 Amritsar Mumbai CSMT Express",
        from: "Amritsar",
        to: "Mumbai CSMT",
        departure: "8:30 PM",
        arrival: "9:30 AM",
        availability: "Waiting List",
      },
      {
        trainName: "14813 Jodhpur Bhopal Express",
        from: "Jodhpur",
        to: "Bhopal",
        departure: "10:00 AM",
        arrival: "9:30 AM",
        availability: "Available",
      },
      {
        trainName: "16592 Hampi Express",
        from: "Mysuru",
        to: "Hubbali",
        departure: "7:00 PM",
        arrival: "10:30 AM",
        availability: "Available",
      },
      {
        trainName: "22204 Duranto Express",
        from: "Secunderabad",
        to: "Visakhapatnam",
        departure: "8:00 PM",
        arrival: "6:30 AM",
        availability: "Waiting List",
      },
      {
        trainName: "12801 Purushottam Express",
        from: "Puri",
        to: "New Delhi",
        departure: "10:00 PM",
        arrival: "4:00 AM",
        availability: "Available",
      },
      {
        trainName: "12023 Jan Shatabdi Express",
        from: "Howrah",
        to: "Patna",
        departure: "2:00 PM",
        arrival: "10:30 PM",
        availability: "Waiting List",
      },
      {
        trainName: "12007 Shatabdi Express",
        from: "Chennai Central",
        to: "Mysuru",
        departure: "6:00 AM",
        arrival: "1:00 PM",
        availability: "Available",
      },
      {
        trainName: "12101 Jnaneswari Express",
        from: "Mumbai LTT",
        to: "Shalimar",
        departure: "8:30 PM",
        arrival: "4:30 AM",
        availability: "Available",
      },
      {
        trainName: "16382 Kanyakumari Pune Express",
        from: "Kanyakumari",
        to: "Pune",
        departure: "8:30 AM",
        arrival: "10:00 PM",
        availability: "Waiting List",
      },
      {
        trainName: "12701 Hussain Sagar Express",
        from: "Mumbai CSMT",
        to: "Hyderabad",
        departure: "10:00 PM",
        arrival: "12:00 PM",
        availability: "Available",
      },
      {
        trainName: "22225 Vande Bharat Express",
        from: "Mumbai CSMT",
        to: "Solapur",
        departure: "4:00 PM",
        arrival: "10:30 PM",
        availability: "Available",
      },
      {
        trainName: "22689 Ahmedabad Yesvantpur Express",
        from: "Ahmedabad",
        to: "Yesvantpur",
        departure: "7:00 PM",
        arrival: "3:00 AM",
        availability: "Available",
      },
      {
        trainName: "12245 Duranto Express",
        from: "Howrah",
        to: "SMVT Bengaluru",
        departure: "10:30 AM",
        arrival: "4:00 PM",
        availability: "Waiting List",
      },
      {
        trainName: "18463 Prashanti Express",
        from: "Bhubaneswar",
        to: "KSR Bengaluru City",
        departure: "6:00 AM",
        arrival: "12:00 PM",
        availability: "Available",
      },
      {
        trainName: "22404 New Delhi - Puducherry Express",
        from: "New Delhi",
        to: "Puducherry",
        departure: "11:30 PM",
        arrival: "9:30 AM",
        availability: "Available",
      },
      {
        trainName: "12431 Rajdhani Express",
        from: "Trivandrum",
        to: "Hazrat Nizamuddin",
        departure: "7:00 PM",
        arrival: "12:30 PM",
        availability: "Available",
      },
      {
        trainName: "22177 Mahanagri Express",
        from: "Mumbai CSMT",
        to: "Varanasi",
        departure: "1:00 AM",
        arrival: "4:00 AM",
        availability: "Waiting List",
      },
      {
        trainName: "22120 Tejas Express",
        from: "Madgaon",
        to: "Mumbai CSMT",
        departure: "4:00 PM",
        arrival: "11:30 AM",
        availability: "Available",
      },
      {
        trainName: "22160 Chennai Central Mumbai CSMT Express",
        from: "Chennai Central",
        to: "Mumbai CSMT",
        departure: "1:00 PM",
        arrival: "12:30 PM",
        availability: "Available",
      },
      {
        trainName: "12313 Rajdhani Express",
        from: "Sealdah",
        to: "New Delhi",
        departure: "5:00 PM",
        arrival: "11:00 AM",
        availability: "Available",
      },
    ];

    sampleData.forEach((train) => {
      const trainCard = document.createElement("div");
      trainCard.className = "train-card";

      trainCard.innerHTML = `
        <div class="train-info">
          <h2>${train.trainName}</h2>
          <p>${train.from} to ${train.to}</p>
          <p>Departure: ${train.departure}</p>
          <p>Arrival: ${train.arrival}</p>
          <p>Status: ${train.availability}</p>
        </div>
        <button class="book-button">Book Now</button>
      `;

      resultsSection.appendChild(trainCard);
    });
  });

  
  